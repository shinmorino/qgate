from .model import Operator

class FrameBegin(Operator) :
    pass

class FrameEnd(Operator) :
    pass

