import numpy as np
from . import glue

class NativeQubitStates :
    def __init__(self, ptr) :
        self.ptr = ptr
        
    def __del__(self) :
        self.delete()

    def delete(self) :
        if hasattr(self, 'ptr') :
            glue.qubit_states_delete(self.ptr)
            del self.ptr

    def get_n_lanes(self) :
        return glue.qubit_states_get_n_lanes(self.ptr)
    
    def reset_lane_states(self) :
        self.lane_states = [-1] * self.get_n_lanes()
    
    def get_lane_state(self, lane) :
        return self.lane_states[lane]
    
    def set_lane_state(self, lane, value) :
        self.lane_states[lane] = value

