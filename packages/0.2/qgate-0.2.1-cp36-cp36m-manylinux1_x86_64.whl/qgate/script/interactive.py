from .scripts import *
import qgate

_sim = qgate.simulator.cpu()

def run(*ops) :
    pass
    
def prob(*qregs) :
    _sim.
    
def state(*qregs)

