

        import random
        for idx in range(n_samples) :
            redprobs = probs.copy()
            v = 0
            for bitpos in range(len(qreg_ordering)) :
                rnum = random.random()
                p_zero = np.sum(redprobs[::2])
                if rnum < p_zero :
                    redprobs = redprobs[::2] / p_zero
                else :
                    redprobs = redprobs[1::2] / (1. - p_zero)
                    v |= (1 << bitpos)
            obs[0][idx] = v
